//
//  TestTwoVC.swift
//  Example
//
//  Created by syed fazal abbas on 21/04/24.
//  Copyright © 2024 Ryan Nystrom. All rights reserved.
//

import UIKit

class TestTwoVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
