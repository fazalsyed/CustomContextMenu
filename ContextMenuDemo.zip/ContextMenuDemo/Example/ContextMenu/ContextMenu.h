//
//  ContextMenu.h
//  ContextMenu
//
//  Created by Ryan Nystrom on 3/10/18.
//  Copyright © 2018 Ryan Nystrom. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ContextMenu.
FOUNDATION_EXPORT double ContextMenuVersionNumber;

//! Project version string for ContextMenu.
FOUNDATION_EXPORT const unsigned char ContextMenuVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ContextMenu/PublicHeader.h>


